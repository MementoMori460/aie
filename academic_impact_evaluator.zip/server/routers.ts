import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { router, protectedProcedure, publicProcedure } from "./_core/trpc";
import { calculateHIS, type DimensionScores, type CascadeMetrics } from "./hisCalculator";
import { calculateCascadeMultipliersFromDimensions, calculate5LevelCascadeFromDimensions } from "./cascadeEngine";
import { z } from "zod";
import * as db from "./db";
import { extractTextFromPDF, extractPaperMetadata, suggestIndicatorValues } from "./pdfProcessor";
import { uploadPdfFromBase64, cleanupTempFile } from "./fileUpload";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  evaluation: router({
    // Create a new evaluation
    create: protectedProcedure
      .input(z.object({
        paperTitle: z.string(),
        paperAuthors: z.string().optional(),
        paperDoi: z.string().optional(),
        paperYear: z.number().optional(),
        paperJournal: z.string().optional(),
        paperAbstract: z.string().optional(),
        evaluationMode: z.enum(["quick", "comprehensive"]).default("quick"),
      }))
      .mutation(async ({ ctx, input }) => {
        const evaluationId = await db.createEvaluation({
          userId: ctx.user.id,
          ...input,
        });
        return { evaluationId };
      }),

    // Get evaluation by ID
    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getEvaluationById(input.id);
      }),

    // List user's evaluations
    list: protectedProcedure
      .query(async ({ ctx }) => {
        return await db.getUserEvaluations(ctx.user.id);
      }),

    // Update evaluation
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        paperTitle: z.string().optional(),
        paperAuthors: z.string().optional(),
        paperDoi: z.string().optional(),
        paperYear: z.number().optional(),
        paperJournal: z.string().optional(),
        paperAbstract: z.string().optional(),
        // Dimension scores (D1-D16)
        D1: z.number().optional(),
        D2: z.number().optional(),
        D3: z.number().optional(),
        D4: z.number().optional(),
        D5: z.number().optional(),
        D6: z.number().optional(),
        D7: z.number().optional(),
        D8: z.number().optional(),
        D9: z.number().optional(),
        D10: z.number().optional(),
        D11: z.number().optional(),
        D12: z.number().optional(),
        D13: z.number().optional(),
        D14: z.number().optional(),
        D15: z.number().optional(),
        D16: z.number().optional(),
        status: z.enum(["draft", "completed"]).optional(),
        completedAt: z.date().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        
        // Auto-calculate HIS if dimension scores are provided
        if (data.D1 !== undefined || data.D2 !== undefined || data.D3 !== undefined || data.D4 !== undefined) {
          const scores: DimensionScores = {
            D1: data.D1,
            D2: data.D2,
            D3: data.D3,
            D4: data.D4,
            D5: data.D5,
            D6: data.D6,
            D7: data.D7,
            D8: data.D8,
            D9: data.D9,
            D10: data.D10,
            D11: data.D11,
            D12: data.D12,
            D13: data.D13,
            D14: data.D14,
            D15: data.D15,
            D16: data.D16,
          };
          
          // Determine mode based on which dimensions are filled
          const hasExtendedDimensions = data.D5 !== undefined || data.D6 !== undefined || data.D7 !== undefined;
          const mode = hasExtendedDimensions ? "comprehensive" : "quick";
          
          // Cascade metrics will be calculated for comprehensive mode
          let cascadeMetrics: CascadeMetrics | undefined;
          
          // Auto-calculate cascade multipliers for comprehensive mode
          if (mode === "comprehensive") {
            const cascadeResults = calculateCascadeMultipliersFromDimensions(scores);
            
            // Update cascade metrics for HIS calculation
            cascadeMetrics = cascadeResults;
          }
          
          // Calculate HIS
          const HIS = calculateHIS(mode, scores, cascadeMetrics);
          
          // Prepare data for database (convert to string format)
          const dbData: any = { ...data };
          
          // Convert dimension scores to scoreD1, scoreD2 format for database
          for (let i = 1; i <= 16; i++) {
            const dimKey = `D${i}` as keyof typeof data;
            const score = data[dimKey];
            if (score !== undefined && typeof score === 'number') {
              dbData[`scoreD${i}`] = score.toFixed(2);
              delete dbData[dimKey]; // Remove D1 format
            }
          }
          
          // Add calculated metrics
          dbData.scoreHIS = HIS.toFixed(2);
          if (cascadeMetrics) {
            dbData.cascadeMultiplier = cascadeMetrics.cascadeMultiplier.toFixed(2);
            dbData.economicMultiplier = cascadeMetrics.economicMultiplier.toFixed(2);
            dbData.socialMultiplier = cascadeMetrics.socialMultiplier.toFixed(2);
            dbData.scientificMultiplier = cascadeMetrics.scientificMultiplier.toFixed(2);
            dbData.environmentalMultiplier = cascadeMetrics.environmentalMultiplier.toFixed(2);
            dbData.networkEffectScore = cascadeMetrics.networkEffectScore.toFixed(2);
          }
          
          await db.updateEvaluation(id, dbData);
          return { success: true, HIS, cascadeMetrics };
        }
        
        // No dimension scores provided, just update other fields
        await db.updateEvaluation(id, data);
        return { success: true };
      }),

    // Delete evaluation
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteEvaluation(input.id);
        return { success: true };
      }),
  }),

  indicator: router({
    // Save indicator value
    save: protectedProcedure
      .input(z.object({
        evaluationId: z.number(),
        indicatorCode: z.string(),
        rawValue: z.string().optional(),
        normalizedScore: z.string().optional(),
        metadata: z.any().optional(),
      }))
      .mutation(async ({ input }) => {
        const indicatorId = await db.saveIndicator(input);
        return { indicatorId };
      }),

    // Get all indicators for an evaluation
    list: protectedProcedure
      .input(z.object({ evaluationId: z.number() }))
      .query(async ({ input }) => {
        return await db.getEvaluationIndicators(input.evaluationId);
      }),

    // Get specific indicator
    get: protectedProcedure
      .input(z.object({
        evaluationId: z.number(),
        indicatorCode: z.string(),
      }))
      .query(async ({ input }) => {
        return await db.getIndicatorByCode(input.evaluationId, input.indicatorCode);
      }),
  }),

  pdf: router({
    upload: protectedProcedure
      .input(z.object({ 
        base64Data: z.string(),
        filename: z.string(),
      }))
      .mutation(async ({ input }) => {
        const uploadResult = await uploadPdfFromBase64(input.base64Data, input.filename);
        return uploadResult;
      }),
    extractMetadata: protectedProcedure
      .input(z.object({ localPath: z.string() }))
      .mutation(async ({ input }) => {
        try {
          const text = await extractTextFromPDF(input.localPath);
          const metadata = await extractPaperMetadata(text);
          // Clean up temp file after extraction
          cleanupTempFile(input.localPath);
          return metadata;
        } catch (error) {
          // Clean up temp file even if extraction fails
          cleanupTempFile(input.localPath);
          throw error;
        }
      }),
    suggestIndicators: protectedProcedure
      .input(
        z.object({
          paperTitle: z.string(),
          paperAuthors: z.string().optional(),
          paperYear: z.number().optional(),
          paperJournal: z.string().optional(),
          paperAbstract: z.string(),
          indicatorCodes: z.array(z.string()),
        })
      )
      .mutation(async ({ input }) => {
        const metadata = {
          title: input.paperTitle,
          authors: input.paperAuthors || "",
          doi: "",
          year: input.paperYear || new Date().getFullYear(),
          journal: input.paperJournal || "",
          abstract: input.paperAbstract,
          fullText: "",
        };
        const suggestions = await suggestIndicatorValues(metadata, input.indicatorCodes);
        return suggestions;
      }),
  }),
  
  ai: router({
    analyzeAllIndicators: protectedProcedure
      .input(z.object({
        paperText: z.string(),
        paperMetadata: z.object({
          title: z.string(),
          authors: z.string().optional(),
          year: z.number().optional(),
          journal: z.string().optional(),
          abstract: z.string().optional(),
        }),
      }))
      .mutation(async ({ input }) => {
        const { analyzeIndicatorsWithAI } = await import('./aiIndicatorAnalyzer');
        return await analyzeIndicatorsWithAI(input.paperText, input.paperMetadata);
      }),
  }),
  
  export: router({
    // Export evaluation as Excel
    excel: protectedProcedure
      .input(z.object({ evaluationId: z.number() }))
      .mutation(async ({ input }) => {
        const { generateExcelReport } = await import('./excelExporter');
        
        // Get evaluation data
        const evaluation = await db.getEvaluationById(input.evaluationId);
        if (!evaluation) {
          throw new Error('Evaluation not found');
        }
        
        // Get indicators
        const indicators = await db.getEvaluationIndicators(input.evaluationId);
        
        // Generate Excel
        const excelBuffer = await generateExcelReport({
          paperTitle: evaluation.paperTitle || '',
          paperAuthors: evaluation.paperAuthors || '',
          paperDoi: evaluation.paperDoi || '',
          paperYear: evaluation.paperYear || undefined,
          paperJournal: evaluation.paperJournal || '',
          paperAbstract: evaluation.paperAbstract || '',
          scoreD1: evaluation.scoreD1 || '0',
          scoreD2: evaluation.scoreD2 || '0',
          scoreD3: evaluation.scoreD3 || '0',
          scoreD4: evaluation.scoreD4 || '0',
          scoreHIS: evaluation.scoreHIS || '0',
          indicators: indicators.map((ind) => ({
            code: ind.indicatorCode,
            value: parseFloat(ind.normalizedScore || '0'),
          })),
        });
        
        // Return base64 encoded
        return {
          data: excelBuffer.toString('base64'),
          filename: `evaluation_${input.evaluationId}.xlsx`,
        };
      }),
    
    // Export evaluation as PDF
    pdf: protectedProcedure
      .input(z.object({ evaluationId: z.number() }))
      .mutation(async ({ input }) => {
        const { generatePDFReport } = await import('./pdfExporter');
        
        // Get evaluation data
        const evaluation = await db.getEvaluationById(input.evaluationId);
        if (!evaluation) {
          throw new Error('Evaluation not found');
        }
        
        // Get indicators
        const indicators = await db.getEvaluationIndicators(input.evaluationId);
        
        // Generate PDF
        const pdfBuffer = await generatePDFReport({
          paperTitle: evaluation.paperTitle || '',
          paperAuthors: evaluation.paperAuthors || '',
          paperDoi: evaluation.paperDoi || '',
          paperYear: evaluation.paperYear || undefined,
          paperJournal: evaluation.paperJournal || '',
          paperAbstract: evaluation.paperAbstract || '',
          scoreD1: evaluation.scoreD1 || '0',
          scoreD2: evaluation.scoreD2 || '0',
          scoreD3: evaluation.scoreD3 || '0',
          scoreD4: evaluation.scoreD4 || '0',
          scoreHIS: evaluation.scoreHIS || '0',
          indicators: indicators.map((ind) => ({
            code: ind.indicatorCode,
            value: parseFloat(ind.normalizedScore || '0'),
          })),
        });
        
        // Return base64 encoded
        return {
          data: pdfBuffer.toString('base64'),
          filename: `evaluation_${input.evaluationId}.pdf`,
        };
      }),
  }),

  cascade: router({
    // Calculate cascade effects for comprehensive mode
    calculate: protectedProcedure
      .input(z.object({
        dimensionScores: z.record(z.string(), z.number()),
        evaluationMode: z.enum(["quick", "comprehensive"]),
      }))
      .mutation(async ({ input }) => {
        // Only calculate cascade effects for comprehensive mode
        if (input.evaluationMode !== "comprehensive") {
          return {
            cascadeMultiplier: 1.0,
            economicMultiplier: 1.0,
            socialMultiplier: 1.0,
            networkEffectScore: 0,
          };
        }
        
        // Calculate average dimension score
        const scores = Object.values(input.dimensionScores);
        const avgScore = scores.reduce((sum, s) => sum + s, 0) / scores.length;
        
        // Calculate multipliers based on dimension scores
        const economicScore = input.dimensionScores['D5'] || 0;
        const socialScore = input.dimensionScores['D10'] || 0;
        const techScore = input.dimensionScores['D9'] || 0;
        
        // Economic multiplier: 1.5 - 5.0x
        const economicMultiplier = 1.5 + (economicScore / 100) * 3.5;
        
        // Social multiplier: 2.0 - 10.0x
        const socialMultiplier = 2.0 + (socialScore / 100) * 8.0;
        
        // Network effect score (based on collaboration and tech dimensions)
        const collabScore = input.dimensionScores['D15'] || 0;
        const networkEffectScore = (techScore + collabScore) / 2;
        
        // Overall cascade multiplier (weighted average)
        const cascadeMultiplier = (
          economicMultiplier * 0.4 +
          socialMultiplier * 0.3 +
          (1 + networkEffectScore / 100) * 0.3
        );
        
        return {
          cascadeMultiplier: Math.min(cascadeMultiplier, 10.0), // Cap at 10x
          economicMultiplier,
          socialMultiplier,
          networkEffectScore,
        };
      }),
  }),
});

export type AppRouter = typeof appRouter;
