import { useState } from "react";
import { useRoute, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ArrowLeft, Download, TrendingUp, Network, Zap } from "lucide-react";
import { COMPREHENSIVE_DIMENSIONS } from "../../../shared/comprehensiveDimensions";

export default function EvaluationReport() {
  const [, params] = useRoute("/evaluation/report/:id");
  const [, setLocation] = useLocation();
  const evaluationId = params?.id ? parseInt(params.id) : null;

  const { data: evaluation, isLoading } = trpc.evaluation.get.useQuery(
    { id: evaluationId! },
    { enabled: !!evaluationId }
  );

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!evaluation) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Alert>
          <AlertDescription>Değerlendirme bulunamadı</AlertDescription>
        </Alert>
      </div>
    );
  }

  const isComprehensive = evaluation.evaluationMode === "comprehensive";
  const cascadeMultiplier = parseFloat(evaluation.cascadeMultiplier || "1.0");
  const economicMultiplier = parseFloat(evaluation.economicMultiplier || "1.0");
  const socialMultiplier = parseFloat(evaluation.socialMultiplier || "1.0");
  const networkEffectScore = parseFloat(evaluation.networkEffectScore || "0");
  const his = parseFloat(evaluation.scoreHIS || "0");

  // Get dimension scores
  const dimensionScores: Record<string, number> = {};
  for (let i = 1; i <= 16; i++) {
    const key = `scoreD${i}` as keyof typeof evaluation;
    const value = evaluation[key];
    if (value) {
      dimensionScores[`D${i}`] = parseFloat(value as string);
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20 py-8">
      <div className="container max-w-6xl">
        {/* Header */}
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => setLocation("/evaluations")}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Değerlendirmelere Dön
          </Button>

          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2">Değerlendirme Raporu</h1>
              <p className="text-muted-foreground">{evaluation.paperTitle}</p>
            </div>
            <div className="flex gap-2">
              <Badge variant={isComprehensive ? "default" : "secondary"} className="text-lg px-4 py-2">
                {isComprehensive ? "Kapsamlı Mod" : "Hızlı Mod"}
              </Badge>
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                PDF İndir
              </Button>
            </div>
          </div>
        </div>

        {/* HIS Score */}
        <Card className="mb-8 border-primary/20 bg-gradient-to-br from-primary/5 to-primary/10">
          <CardHeader>
            <CardTitle className="text-2xl">Bütünsel Etki Skoru (HIS)</CardTitle>
            <CardDescription>Makalenin genel etki değerlendirmesi</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-center">
              <div className="text-6xl font-bold text-primary">{his.toFixed(1)}</div>
              <div className="ml-4 text-muted-foreground">/100</div>
            </div>
          </CardContent>
        </Card>

        {/* Cascade Effects (Comprehensive Mode Only) */}
        {isComprehensive && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            {/* Overall Cascade Multiplier */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-blue-500" />
                  Zincirleme Etki Çarpanı
                </CardTitle>
                <CardDescription>Toplam etki çarpma katsayısı</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-4xl font-bold text-blue-600">{cascadeMultiplier.toFixed(2)}x</div>
                <p className="text-sm text-muted-foreground mt-2">
                  Makalenin etkisi {cascadeMultiplier.toFixed(2)} kat artırılmıştır
                </p>
              </CardContent>
            </Card>

            {/* Economic Multiplier */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="w-5 h-5 text-green-500" />
                  Ekonomik Çarpan
                </CardTitle>
                <CardDescription>Ekonomik etki katsayısı</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-4xl font-bold text-green-600">{economicMultiplier.toFixed(2)}x</div>
                <p className="text-sm text-muted-foreground mt-2">
                  Aralık: 1.5x - 5.0x
                </p>
              </CardContent>
            </Card>

            {/* Social Multiplier */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Network className="w-5 h-5 text-purple-500" />
                  Sosyal Çarpan
                </CardTitle>
                <CardDescription>Sosyal etki katsayısı</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-4xl font-bold text-purple-600">{socialMultiplier.toFixed(2)}x</div>
                <p className="text-sm text-muted-foreground mt-2">
                  Aralık: 2.0x - 10.0x
                </p>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Network Effect */}
        {isComprehensive && networkEffectScore > 0 && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Ağ Etkileri</CardTitle>
              <CardDescription>İşbirliği ve teknoloji yayılımı</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4">
                <div className="text-3xl font-bold text-orange-600">{networkEffectScore.toFixed(1)}/100</div>
                <div className="flex-1">
                  <div className="w-full bg-muted rounded-full h-3">
                    <div
                      className="bg-orange-500 h-3 rounded-full transition-all duration-300"
                      style={{ width: `${networkEffectScore}%` }}
                    />
                  </div>
                  <p className="text-sm text-muted-foreground mt-2">
                    Makalenin işbirliği ve teknoloji transferi potansiyeli
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Dimension Scores */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Boyut Skorları</CardTitle>
            <CardDescription>
              {isComprehensive ? "16 boyut değerlendirmesi" : "4 ana boyut değerlendirmesi"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {COMPREHENSIVE_DIMENSIONS.filter(dim => {
                // Show all dimensions for comprehensive, only D1-D4 for quick
                if (isComprehensive) return true;
                return ["D1", "D2", "D3", "D4"].includes(dim.code);
              }).map((dimension) => {
                const score = dimensionScores[dimension.code] || 0;
                const hasScore = score > 0;

                if (!hasScore && !isComprehensive) return null;

                return (
                  <div key={dimension.code} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">{dimension.code}</Badge>
                        <span className="font-medium">{dimension.name}</span>
                      </div>
                      <span className="text-lg font-semibold">{score.toFixed(0)}/100</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div
                        className="bg-primary h-2 rounded-full transition-all duration-300"
                        style={{ width: `${score}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Cascade Effect Visualization (Comprehensive Mode) */}
        {isComprehensive && (
          <Card>
            <CardHeader>
              <CardTitle>Zincirleme Etki Analizi</CardTitle>
              <CardDescription>Makalenin dolaylı ve uzun vadeli etkileri</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Level 1: Primary Impact */}
                <div className="border-l-4 border-blue-500 pl-4">
                  <h3 className="font-semibold text-lg mb-2">Birincil Etki (Seviye 1)</h3>
                  <p className="text-muted-foreground">
                    Makalenin doğrudan akademik ve bilimsel katkıları. Atıflar, metodoloji geliştirme, bilgi üretimi.
                  </p>
                  <div className="mt-2 text-sm text-blue-600 font-medium">
                    Çarpan: 1.0x (Temel etki)
                  </div>
                </div>

                {/* Level 2: Secondary Impact */}
                <div className="border-l-4 border-green-500 pl-4">
                  <h3 className="font-semibold text-lg mb-2">İkincil Etki (Seviye 2)</h3>
                  <p className="text-muted-foreground">
                    Araştırma bulgularının uygulamaya dönüşmesi. Teknoloji transferi, patent, ürün geliştirme.
                  </p>
                  <div className="mt-2 text-sm text-green-600 font-medium">
                    Çarpan: {(economicMultiplier * 0.85).toFixed(2)}x (Ekonomik etki × 0.85)
                  </div>
                </div>

                {/* Level 3: Tertiary Impact */}
                <div className="border-l-4 border-purple-500 pl-4">
                  <h3 className="font-semibold text-lg mb-2">Üçüncül Etki (Seviye 3)</h3>
                  <p className="text-muted-foreground">
                    Toplumsal ve ekonomik dönüşümler. İstihdam, sağlık iyileştirmeleri, çevresel kazanımlar.
                  </p>
                  <div className="mt-2 text-sm text-purple-600 font-medium">
                    Çarpan: {(socialMultiplier * 0.7).toFixed(2)}x (Sosyal etki × 0.70)
                  </div>
                </div>

                {/* Level 4: Quaternary Impact */}
                <div className="border-l-4 border-orange-500 pl-4">
                  <h3 className="font-semibold text-lg mb-2">Dördüncül Etki (Seviye 4)</h3>
                  <p className="text-muted-foreground">
                    Sistemik değişimler ve politika etkileri. Yasal düzenlemeler, eğitim reformları, kültürel değişim.
                  </p>
                  <div className="mt-2 text-sm text-orange-600 font-medium">
                    Çarpan: {(cascadeMultiplier * 0.55).toFixed(2)}x (Toplam çarpan × 0.55)
                  </div>
                </div>

                {/* Level 5: Quinary Impact */}
                <div className="border-l-4 border-red-500 pl-4">
                  <h3 className="font-semibold text-lg mb-2">Beşincil Etki (Seviye 5)</h3>
                  <p className="text-muted-foreground">
                    Uzun vadeli küresel etkiler. Paradigma değişimleri, yeni araştırma alanları, nesiller arası fayda.
                  </p>
                  <div className="mt-2 text-sm text-red-600 font-medium">
                    Çarpan: {(cascadeMultiplier * 0.4).toFixed(2)}x (Toplam çarpan × 0.40)
                  </div>
                </div>

                {/* Total Impact */}
                <div className="bg-primary/10 rounded-lg p-4 border-2 border-primary">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold text-lg">Toplam Zincirleme Etki</h3>
                      <p className="text-sm text-muted-foreground">
                        Tüm seviyelerin kümülatif etkisi
                      </p>
                    </div>
                    <div className="text-3xl font-bold text-primary">
                      {(1.0 + economicMultiplier * 0.85 + socialMultiplier * 0.7 + cascadeMultiplier * 0.55 + cascadeMultiplier * 0.4).toFixed(2)}x
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
