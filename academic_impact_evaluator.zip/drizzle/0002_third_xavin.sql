ALTER TABLE `evaluations` ADD `scoreD5` decimal(5,2);--> statement-breakpoint
ALTER TABLE `evaluations` ADD `scoreD6` decimal(5,2);--> statement-breakpoint
ALTER TABLE `evaluations` ADD `scoreD7` decimal(5,2);--> statement-breakpoint
ALTER TABLE `evaluations` ADD `scoreD8` decimal(5,2);--> statement-breakpoint
ALTER TABLE `evaluations` ADD `scoreD9` decimal(5,2);--> statement-breakpoint
ALTER TABLE `evaluations` ADD `scoreD10` decimal(5,2);--> statement-breakpoint
ALTER TABLE `evaluations` ADD `scoreD11` decimal(5,2);--> statement-breakpoint
ALTER TABLE `evaluations` ADD `scoreD12` decimal(5,2);--> statement-breakpoint
ALTER TABLE `evaluations` ADD `scoreD13` decimal(5,2);--> statement-breakpoint
ALTER TABLE `evaluations` ADD `scoreD14` decimal(5,2);--> statement-breakpoint
ALTER TABLE `evaluations` ADD `scoreD15` decimal(5,2);--> statement-breakpoint
ALTER TABLE `evaluations` ADD `scoreD16` decimal(5,2);--> statement-breakpoint
ALTER TABLE `evaluations` ADD `cascadeMultiplier` decimal(5,2);--> statement-breakpoint
ALTER TABLE `evaluations` ADD `economicMultiplier` decimal(5,2);--> statement-breakpoint
ALTER TABLE `evaluations` ADD `socialMultiplier` decimal(5,2);--> statement-breakpoint
ALTER TABLE `evaluations` ADD `networkEffectScore` decimal(5,2);